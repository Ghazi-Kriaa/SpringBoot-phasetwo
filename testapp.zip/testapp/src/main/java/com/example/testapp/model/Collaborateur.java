package com.example.testapp.model;




import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class Collaborateur {

private int id;
private String name ;

}
